package com.example.newrestapi;

/**
 * Created by Tmura on 01/11/2016.
 */

public class QueueMonitor {
//
//        protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.queue_monitor);
//
//    }
//
//    public void onAgent(View view){
//        Intent intent=new Intent(QueueMonitor.this,AgentMonitor.class);
//        startActivity(intent);
//    }
//    public void onCampt(View view){
//        Intent intent=new Intent(QueueMonitor.this,CampMonitor.class);
//        startActivity(intent);
//    }
//
//    public void onQueue(View view){
//        Intent intent=new Intent(QueueMonitor.this,QueueMonitor.class);
//        startActivity(intent);
//    }
//
//    public void onIVR(View view){
//        Intent intent=new Intent(QueueMonitor.this,IvrMonitor.class);
//        startActivity(intent);
//    }
//
//    public void onEXIT(View view){
//
////        // TODO: 01/11/2016  exit application
//        Intent intent=new Intent(QueueMonitor.this,CampMonitor.class);
//        startActivity(intent);
//    }

}

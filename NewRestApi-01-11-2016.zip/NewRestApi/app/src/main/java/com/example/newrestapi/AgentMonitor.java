package com.example.newrestapi;

import android.app.Activity;
import android.content.Intent;
import android.media.ExifInterface;
import android.os.Bundle;
import android.view.View;

/**
 * Created by Administrator on 30/10/2016.
 */

public class AgentMonitor extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.agent_monitor);
    }


    public void onAgent(View view){
        Intent intent=new Intent(AgentMonitor.this,AgentMonitor.class);
        startActivity(intent);
    }
    public void onCampt(View view){
        Intent intent=new Intent(AgentMonitor.this,CampMonitor.class);
        startActivity(intent);
    }

    public void onQueue(View view){
        Intent intent=new Intent(AgentMonitor.this,QueueMonitor.class);
        startActivity(intent);
    }

    public void onIVR(View view){
        Intent intent=new Intent(AgentMonitor.this,IvrMonitor.class);
        startActivity(intent);
    }

    public void onEXIT(View view){

//        // TODO: 01/11/2016  exit application
       Intent intent=new Intent(AgentMonitor.this,CampMonitor.class);
//        startActivity(intent);

    }
}

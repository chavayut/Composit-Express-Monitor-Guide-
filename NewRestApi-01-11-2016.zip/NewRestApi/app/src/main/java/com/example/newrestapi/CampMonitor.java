package com.example.newrestapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;


/**
 * Created by Administrator on 30/10/2016.
 */

public class CampMonitor extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.campaign_monitor);

    }

    public void onAgent(View view){
        Intent intent=new Intent(CampMonitor.this,AgentMonitor.class);
        startActivity(intent);
    }
    public void onCampt(View view){
        Intent intent=new Intent(CampMonitor.this,CampMonitor.class);
        startActivity(intent);
    }

    public void onQueue(View view){
        Intent intent=new Intent(CampMonitor.this,QueueMonitor.class);
        startActivity(intent);
    }

    public void onIVR(View view){
        Intent intent=new Intent(CampMonitor.this,IvrMonitor.class);
        startActivity(intent);
    }

    public void onEXIT(View view){

//        // TODO: 01/11/2016  exit application
        Intent intent=new Intent(CampMonitor.this,CampMonitor.class);
        startActivity(intent);
    }
}

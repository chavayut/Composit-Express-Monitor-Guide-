package com.example.newrestapi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by Tmura on 01/11/2016.
 */

public class IvrMonitor {
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.ivr_monitor);
//
//    }
//
//    public void onAgent(View view){
//        Intent intent=new Intent(IvrMonitor.this,AgentMonitor.class);
//        startActivity(intent);
//    }
//    public void onCampt(View view){
//        Intent intent=new Intent(IvrMonitor.this,CampMonitor.class);
//        startActivity(intent);
//    }
//
//    public void onQueue(View view){
//        Intent intent=new Intent(IvrMonitor.this,QueueMonitor.class);
//        startActivity(intent);
//    }
//
//    public void onIVR(View view){
//        Intent intent=new Intent(IvrMonitor.this,IvrMonitor.class);
//        startActivity(intent);
//    }
//
//    public void onEXIT(View view){
//
////        // TODO: 01/11/2016  exit application
//        Intent intent=new Intent(IvrMonitor.this,CampMonitor.class);
//        startActivity(intent);
//    }

}
